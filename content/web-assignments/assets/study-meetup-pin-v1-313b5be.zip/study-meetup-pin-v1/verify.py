"""공개 동작 확인. 로컬 연습 서버의 고정 상태를 실제로 변경합니다."""
import sys
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, build_opener, HTTPRedirectHandler


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Board(HTMLParser):
    def __init__(self):
        super().__init__()
        self.section = None
        self.groups = {"pinned": [], "regular": []}
        self.buttons = {"pinned": [], "regular": []}
        self.in_button = False
        self.button_text = ""

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "section" and attrs.get("id") in self.groups:
            self.section = attrs["id"]
        if tag == "article" and self.section:
            self.groups[self.section].append(int(attrs["data-id"]))
        if tag == "button" and self.section:
            self.in_button = True
            self.button_text = ""

    def handle_data(self, data):
        if self.in_button:
            self.button_text += data

    def handle_endtag(self, tag):
        if tag == "button" and self.in_button:
            self.buttons[self.section].append(self.button_text.strip())
            self.in_button = False
        if tag == "section":
            self.section = None


def check(base):
    parsed = urlparse(base)
    if parsed.scheme != "http" or parsed.hostname not in ("localhost", "127.0.0.1"):
        raise ValueError("연습용 localhost 또는 127.0.0.1 주소만 입력하세요.")
    opener = build_opener(NoRedirect())

    def request(path, method="GET"):
        req = Request(base.rstrip("/") + path, data=b"" if method == "POST" else None, method=method)
        try:
            with opener.open(req, timeout=5) as res:
                return res.status, res.headers, res.read().decode()
        except HTTPError as error:
            return error.code, error.headers, error.read().decode()

    def expect(pinned, regular):
        status, _, body = request("/notices")
        assert status == 200, f"목록 응답이 {status}입니다."
        board = Board()
        board.feed(body)
        assert board.groups == {"pinned": pinned, "regular": regular}, f"목록 분류 확인: {board.groups}"
        assert board.buttons["pinned"] == ["고정 해제"] * len(pinned), "고정된 글의 버튼 문구를 확인하세요."
        assert board.buttons["regular"] == ["고정하기"] * len(regular), "일반 글의 버튼 문구를 확인하세요."

    def toggle(id):
        status, headers, _ = request(f"/notices/{id}/pin", "POST")
        assert status == 302, f"POST 후 redirect가 필요합니다. 실제 상태: {status}"
        location = urlparse(headers.get("Location", ""))
        assert location.path == "/notices" and location.fragment == "board", "redirect 주소를 확인하세요."

    expect([], [1, 2, 3])
    toggle(2)
    expect([2], [1, 3])
    expect([2], [1, 3])  # 새로고침만으로 상태가 반전되지 않아야 합니다.
    toggle(2)
    expect([], [1, 2, 3])
    for id in (1, 2, 3):
        toggle(id)
    expect([1, 2, 3], [])
    assert request("/notices/999/pin", "POST")[0] == 404, "없는 id는 404여야 합니다."
    assert request("/notices/1/pin")[0] == 405, "GET으로 상태를 변경하면 안 됩니다."
    expect([1, 2, 3], [])
    for id in (1, 2, 3):
        toggle(id)
    expect([], [1, 2, 3])
    print("통과: 고정·해제·중복 없는 분류·버튼·redirect·없는 id·GET 제한 확인")


if __name__ == "__main__":
    try:
        check(sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8086")
    except (AssertionError, ValueError, URLError, KeyError) as error:
        print(f"확인 필요: {error}")
        print("부분 상태가 남을 수 있습니다. 코드 수정 후 서버를 재시작하고 다시 확인하세요.")
        sys.exit(1)
