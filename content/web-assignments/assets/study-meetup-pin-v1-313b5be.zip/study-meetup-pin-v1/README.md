# 과제 2. 스터디 안내글 고정·고정 해제

스터디 모임 안내판에서 중요한 글을 상단에 고정합니다. 오전 `BlogMVC`에서 배운 고정 기능을 새로운 데이터와 한 페이지 화면에 적용하는 과제입니다.

**핵심 목표:** boolean 상태 변경 → 고정/일반 목록 분리 → POST 처리와 redirect → Thymeleaf 버튼 표시.
예상 30~40분. 오후 REST API, DB·배포·새 CRUD는 이번 과제가 아닙니다.

## 시작하기

1. IntelliJ에서 이 `02-pin-board` 폴더를 Gradle 프로젝트로 여세요.
2. Project SDK와 Gradle JVM을 **Java 21**로 설정하세요. 오전 BlogMVC와 같은 Java 21 / Spring Boot 4.1.1입니다.
3. `StudyBoardApplication`의 main을 실행하거나 터미널에서 `./gradlew bootRun`을 실행하세요.
4. <http://localhost:8086/notices>에 접속하세요. 8086이 사용 중이면 `application.properties`에서 포트를 바꾸세요.

시작 상태에서는 일반 안내글 세 개만 보입니다. 고정 기능의 TODO는 비어 있으므로 버튼을 눌러도 아직 고정되지 않습니다. 404가 나오면 미구현 POST 주소인지 먼저 확인하세요. HTML을 파일로 직접 열지 않습니다.

## 화면과 데이터

| id | 제목 | 시작 상태 |
| --- | --- | --- |
| 1 | 이번 주 모각코 시간 | 고정 안 됨 |
| 2 | Java 인터페이스 연습 모임 | 고정 안 됨 |
| 3 | 코딩 테스트 풀이 공유 | 고정 안 됨 |

위 세 글과 제목·본문·조회 기능·디자인은 AI 제공 자료입니다. 글 추가·수정·삭제를 만들 필요는 없습니다. 화면은 한 페이지이며 고정 안내/일반 안내 두 구역으로 나뉩니다.

## 요구사항 1. 고정 상태 저장

`model/Notice.java`에 다음 계약을 완성하세요. `Notice`는 일반 Java 클래스이며 enum이 아닙니다.

| 항목 | 지정 이름·타입 | 해야 할 일 |
| --- | --- | --- |
| 추가할 필드 | `private boolean pinned` | 글마다 고정 여부 보관. 처음에는 false |
| 기존 메서드 수정 | `public boolean isPinned()` | 그 글의 실제 고정 상태 반환 |
| 기존 메서드 수정 | `public void setPinned(boolean pinned)` | 받은 값으로 그 글의 상태 변경 |

기존 `id`, `title`, `body`와 생성자는 그대로 사용하세요. 임시로 항상 false를 반환하는 코드와 빈 setter를 실제 동작으로 바꿉니다.

## 요구사항 2. 고정 목록과 일반 목록 구분

`repository/NoticeRepository.java`의 세 메서드를 완성하세요.

| 메서드 | 반환·역할 |
| --- | --- |
| `public List<Notice> findPinned()` | pinned가 true인 글만 반환 |
| `public List<Notice> findNotPinned()` | pinned가 false인 글만 반환 |
| `public void updatePinned(Long id, boolean pinned)` | 제공된 `findById(id)`로 글을 찾아 고정 상태 변경 |

- 원본 목록 `notices`에서 글을 지우거나 새 글을 만들지 않습니다.
- 고정된 글은 고정 목록에만, 나머지는 일반 목록에만 있어야 합니다.
- 원래 id 순서를 각 구역 안에서 유지하세요. 별도 정렬 기능은 필요 없습니다.
- 수업에서 쓴 stream/filter 또는 이전에 배운 반복문 중 익숙한 방법을 사용해도 됩니다.

## 요구사항 3. 고정·고정 해제 요청 처리

`controller/NoticeController.java`의 `togglePin`을 완성하세요.

| 항목 | 지정 계약 |
| --- | --- |
| HTTP 요청 | `POST /notices/{id}/pin` |
| 메서드 | `public String togglePin(Long id)` |
| 경로에서 받을 값 | `id` (`@PathVariable`로 연결) |
| 저장소 필드 | 제공된 `noticeRepository` |
| 현재 글 변수 | `Notice notice` |
| 변경 후 상태 변수 | `boolean nextPinned` |
| 완료 후 이동 | `redirect:/notices#board` |

- 현재 상태가 false이면 true로, true이면 false로 바꿉니다.
- 변경은 저장소의 `updatePinned(id, nextPinned)` 역할로 연결하세요.
- 기존 GET 목록 메서드와 Model 키 `pinnedNotices`, `notices`는 제공되어 있습니다.
- POST 후 목록 GET으로 이동하면서 변경된 두 목록을 다시 보여줍니다.
- URL의 `#board`는 브라우저를 목록 위치로 이동시키는 보조 설정입니다. 정확한 이전 스크롤 위치 복원이나 상태 저장 기능은 아닙니다.

없는 id의 글에 대해서는 제공된 `findById`가 404로 처리합니다. 오류 처리 코드는 수정하지 않아도 됩니다. GET 요청만으로 고정 상태를 바꾸면 안 됩니다.

## 요구사항 4. 버튼 문구와 화면 확인

`src/main/resources/templates/notices/index.html`에서 TODO가 있는 버튼 두 곳에 글의 상태를 반영하세요.

- 반복문의 변수명은 `notice`입니다.
- 고정되지 않은 글에는 **고정하기**, 고정된 글에는 **고정 해제**를 표시하세요.
- 오늘 이전에 배운 `th:if`·`th:unless` 또는 조건식과 `th:text`를 사용하세요.
- form의 POST 방식·요청 주소와 목록 반복, 빈 목록 안내, 빨간 오류 스타일은 제공했습니다.
- 두 목록에서 같은 글이 중복 표시되면 화면에서 감추기 전에 저장소의 분류 조건부터 확인하세요.

## 완료 확인표

| 확인 순서 | 기대 동작 |
| --- | --- |
| 처음 실행 | 고정 0개, 일반 3개 |
| 2번 글 고정하기 | 고정 구역에 2번만, 일반 구역에 1·3번 |
| 같은 2번 글 고정 해제 | 고정 0개, 일반 1·2·3번 |
| 1번과 3번을 차례로 고정 | 고정 1·3번, 일반 2번 |
| 브라우저 새로고침 | 현재 상태 유지. 새로고침만으로 다시 반전되지 않음 |
| 세 글 모두 고정 | 일반 구역에 빈 목록 안내 |
| 세 글 모두 고정 해제 | 고정 구역에 빈 목록 안내 |
| 없는 id로 POST | 404. 다른 글은 변경되지 않음 |
| 같은 pin 주소로 GET | 405. 고정 상태는 변경되지 않음 |

서버를 껐다 켜면 처음 상태로 돌아갑니다. 이번 과제는 메모리 저장이므로 정상입니다. 시작 코드에 정답 구현은 없습니다.

최종 구현 후 앱을 재시작한 상태에서 `python3 verify.py`를 실행하면 위 핵심 흐름을 확인합니다. **이 스크립트는 실제 고정 상태를 바꿔 테스트하고 정상 종료 시 모두 해제합니다.** 실패하면 일부 상태가 남을 수 있으므로 재시작 후 다시 확인하세요. 포트 변경 시 `python3 verify.py http://localhost:바꾼포트`로 실행합니다. 내부 코드의 이해도는 별도로 설명해보세요.

## 작성할 파일 순서

1. `src/main/java/com/bam/meetup/model/Notice.java`
2. `src/main/java/com/bam/meetup/repository/NoticeRepository.java`
3. `src/main/java/com/bam/meetup/controller/NoticeController.java`
4. `src/main/resources/templates/notices/index.html`의 버튼 문구

막히면 요구사항 번호와 현재 코드를 알려주세요. [단계별 힌트](hints.md)는 필요할 때만 여세요.

## 범위와 출처

과제 ID: study-meetup-20260910-pin / v1 / 사용자 풀이 전.
화면·샘플·기본 조회·에러 페이지는 AI 제공, TODO는 사용자 구현 영역입니다. 강사 HTML·CSS·디자인을 복사하지 않았습니다. [출처](../provenance.md) · [ERD 과제](../01-erd/README.md).
로컬 Git 기준에서 풀이를 비교합니다. 원격 저장소·GitHub 공개는 연결하지 않았습니다.
