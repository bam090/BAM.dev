package com.bam.meetup.controller;

import com.bam.meetup.repository.NoticeRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class NoticeController {
    private final NoticeRepository noticeRepository;

    public NoticeController(NoticeRepository noticeRepository) {
        this.noticeRepository = noticeRepository;
    }

    @GetMapping({"/", "/notices"})
    public String index(Model model) {
        model.addAttribute("pinnedNotices", noticeRepository.findPinned());
        model.addAttribute("notices", noticeRepository.findNotPinned());
        return "notices/index";
    }

    // TODO 요구사항 3: POST 경로와 경로 변수 연결을 추가하세요.
    public String togglePin(Long id) {
        // TODO 요구사항 3: 현재 상태를 확인하고 반대 상태로 변경하세요.
        return "redirect:/notices#board";
    }
}
