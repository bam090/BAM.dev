package com.bam.meetup.repository;

import com.bam.meetup.model.Notice;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@Repository
public class NoticeRepository {
    private final List<Notice> notices = new ArrayList<>();

    public NoticeRepository() {
        notices.add(new Notice(1L, "이번 주 모각코 시간", "평일 저녁 8시에 모여 각자 공부합니다. 참여는 자유입니다."));
        notices.add(new Notice(2L, "Java 인터페이스 연습 모임", "작은 예제를 직접 작성하고 서로의 접근을 이야기합니다."));
        notices.add(new Notice(3L, "코딩 테스트 풀이 공유", "이번 주 문제에서 막혔던 지점을 하나씩 나눕니다."));
    }

    public Notice findById(Long id) {
        return notices.stream()
                .filter(notice -> notice.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public List<Notice> findPinned() {
        // TODO 요구사항 2: 고정된 글만 반환하세요. 아래는 시작 화면용 빈 목록입니다.
        return new ArrayList<>();
    }

    public List<Notice> findNotPinned() {
        // TODO 요구사항 2: 고정되지 않은 글만 반환하세요. 아래는 임시 전체 목록입니다.
        return new ArrayList<>(notices);
    }

    public void updatePinned(Long id, boolean pinned) {
        // TODO 요구사항 2: 글을 찾아 전달받은 상태를 반영하세요.
    }
}
