package com.bam.meetup.model;

public class Notice {
    private final Long id;
    private final String title;
    private final String body;

    // TODO 요구사항 1: pinned 필드를 추가하세요.

    public Notice(Long id, String title, String body) {
        this.id = id;
        this.title = title;
        this.body = body;
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getBody() {
        return body;
    }

    public boolean isPinned() {
        // TODO 요구사항 1: 임시 반환값을 실제 상태로 바꾸세요.
        return false;
    }

    public void setPinned(boolean pinned) {
        // TODO 요구사항 1: 이 글의 상태를 변경하세요.
    }
}
