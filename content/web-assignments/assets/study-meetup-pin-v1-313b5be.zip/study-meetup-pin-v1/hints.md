# 필요할 때만 보는 힌트

<details><summary>1. 상태를 기억하는 위치</summary>

글마다 값이 달라야 하므로 각 Notice 객체의 필드에 상태를 저장합니다. 항상 false를 반환하면 setter에서 바꾼 값을 화면이 알 수 있을까요?

</details>

<details><summary>2. 두 목록을 나누는 기준</summary>

한 글이 두 목록에 동시에 들어가지 않으려면 두 조건은 어떤 관계여야 할까요? 원본에서 삭제하는 것과 조건에 맞는 결과 목록을 만드는 것을 구별하세요.

</details>

<details><summary>3. 상태를 반대로 바꾸기</summary>

지금 상태를 읽은 다음 반대 boolean 값을 구하세요. Java에서 논리값을 반대로 만드는 연산자를 떠올려보세요. 요청 주소에서 id를 받는 방법은 수업의 상세 조회와 연결해보세요.

</details>

<details><summary>4. 화면 문구</summary>

반복문 안의 notice가 가진 pinned 상태를 조건으로 사용합니다. 버튼 자체를 두 개로 나눌 수도 있고, 한 버튼의 문구만 조건으로 바꿀 수도 있습니다.

</details>
